from pathlib import Path
from ultralytics import YOLO

root = Path(__file__).resolve().parent
model = YOLO("yolo26n.pt")

model.train(
    data=str(root / "data.yaml"),
    epochs=100,
    imgsz=640,
    batch=16,
    device=0,
    project=str(root / "runs"),
    name="wastewise_gpu"
)
