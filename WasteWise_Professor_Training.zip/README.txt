WasteWise AI - Professor GPU Training Package

Classes:
0 Plastic bottle
1 Aluminium can
2 Cardboard
3 Paper
4 Glass jar
5 Food waste
6 Battery
7 E-waste

Recommended starting dataset: balanced-800.

Expected folder layout:

WasteWise_Professor/
  data.yaml
  train_yolo26.py
  requirements.txt
  dataset/
    images/
      train/
      val/
    labels/
      train/
      val/

The images and labels are NOT included in this ZIP.
Copy the balanced-800 images and labels into dataset/.

Install:
pip install -r requirements.txt

Train:
python train_yolo26.py

The script uses a YOLO26 nano starting checkpoint.
Adjust batch size to available GPU memory.
Confirm model and Ultralytics version compatibility.

Before training, check:
- dataset licences and redistribution permissions
- class IDs and label quality
- duplicate images across training and validation
- whether new images are representative of real-world waste

After training, return:
- best.pt
- training results and validation metrics
- exact Ultralytics and PyTorch versions
- model configuration and image size

Keep the existing Android model unchanged until the
new model is validated and exported for ExecuTorch.
